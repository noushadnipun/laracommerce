<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TermTaxonomy;
use App\Models\Term;
use App\Models\Category;

class CategoryController extends Controller
{
    protected function getTaxonomyData(Request $request)
    {
        $checkTaxonomy = TermTaxonomy::where('slug', $request->taxonomy)->where('term_type', $request->type)->first();
        return [
            'slug' => $checkTaxonomy ? $checkTaxonomy['slug'] : null,
            'name' => $checkTaxonomy ? $checkTaxonomy['name'] : null,
            'term_slug' => $request->type
        ];
    }

    public function index(Request $request){
        $taxonomyData = $this->getTaxonomyData($request);
        $taxonomy_name = $taxonomyData['name'];
        $taxonomy_slug = $taxonomyData['slug'];
        $term_slug = $taxonomyData['term_slug'];

        if(empty($taxonomy_slug)){
           return view('admin.404', ['message' => 'Invalid Taxonomy Type']);
        }

        if($request->id){
            $category = Category::find($request->id);
        } else {
            $category = '';
        }
        return view('admin.common.category.index', compact('taxonomy_name', 'taxonomy_slug', 'term_slug', 'category'));
    }

     //store
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'slug' => 'required|unique:categories,slug',
        ]);

        $taxonomyData = $this->getTaxonomyData($request);
        $taxonomy_name = $taxonomyData['name'];
        $taxonomy_slug = $taxonomyData['slug'];
        $term_slug = $taxonomyData['term_slug'];

        if(empty($taxonomy_slug)){
           return view('admin.404', ['message' => 'Invalid Taxonomy Type']);
        } else {
            $data = new Category();
            $data->taxonomy_type = $taxonomy_slug;
            $data->name = $request->name;
            $data->slug = $request->slug;
            $data->description = $request->description;
            $data->parent_id = $request->parent_id;
            $data->image = $request->catimg_id;
            $data->save();
            return redirect()->back()->with('success', 'Added Successfully');
        }
        
    }
    //update
    public function update(Request $request)
    {
        $taxonomyData = $this->getTaxonomyData($request);
        $taxonomy_name = $taxonomyData['name'];
        $taxonomy_slug = $taxonomyData['slug'];
        $term_slug = $taxonomyData['term_slug'];

        if(empty($taxonomy_slug)){
           return view('admin.404', ['message' => 'Invalid Taxonomy Type']);
        }  else {
            $data = Category::find($request->id);
            $data->taxonomy_type = $taxonomy_slug;
            $data->name = $request->name;
            $data->slug = $request->slug;
            $data->description = $request->description;
            $data->parent_id = $request->parent_id;
            $data->image = $request->catimg_id;
            $data->save();
            return redirect()->back()->with('success', 'Edited Successfully');
        }
        
    }

      public function destroy(Request $request)
    {
        $id = $request->id;
        $data = Category::find($id);
        //Chnage all child id which under this id
        $changeParent = Category::where('parent_id', $id)->get();
        if(!empty($changeParent)){
            foreach($changeParent as $change){
                $upParent = Category::where('parent_id', $id)->first();
                $upParent->parent_id = null;
                $upParent->save();
            }
        }

        $data->delete();
        return redirect()->back()->with('delete', 'Deleted Successfully');
    }
}
