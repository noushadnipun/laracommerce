<?php
namespace App\Helpers\Frontend;

use \App\Models\Product;

class ProductView {

     /**
     * Price Sign BDT
     */
    public static function priceSign($price){
        return '৳'.$price;
    }

     /**
     * Product View Desoign
     */

    public static function view($query = '', $noQuery = ''){
       ob_start();
       foreach($query as $product) { 
        ?>
        <article class="single_product">
            <figure>
                <div class="product_thumb">
                    <a class="primary_img" href="<?php echo route('frontend_single_product', $product->slug);?>"><img src="<?php echo $product->getFeaturedImageUrl(); ?>" alt=""></a>
                    <div class="label_product">
                    <?php 
                        $isOutOfStock = isset($product->current_stock) ? ((int)$product->current_stock <= 0) : (method_exists($product, 'isOutOfStock') ? $product->isOutOfStock() : false);
                        if($isOutOfStock){
                            echo '<span class="label_stockout">sold</span>';
                        } else if(!empty($product->sale_price)) {
                            echo '<span class="label_sale">sale</span>';
                        }
                    ?>
                    </div>
                    <div class="action_links">
                        <ul>
                            <li class="quick_button"><a id="<?php echo $product->id;?>" class="modalQuickView" href="javascript:void()" data-toggle="modal" data-target="#modal_box" title="quick view"> <span class="ion-ios-search-strong"></span></a></li>
                        </ul>
                    </div>
                    <div class="add_to_cart">
                        <?php if(!$isOutOfStock){ ?>
                        <form method="POST" action="<?php echo route('frontend_cart_store');?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo $product->id;?>">
                            <?php
                            if(isset($product['attribute'])){ ?>
                                <a id="<?php echo $product->id;?>" class="add_to_cart_btn modalQuickView" type="button" title="add to cart" data-toggle="modal" data-target="#modal_box">Add to cart</a>
                            <?php }else{ ?>
                                <button class="add_to_cart_btn" type="submit" title="add to cart">Add to cart</button>
                            <?php } ?>
                        </form>
                        <?php } else { ?>
                            <button class="add_to_cart_btn" type="button" title="stock out" disabled>Stock Out</button>
                        <?php } ?>
                    </div>
                </div>
                <figcaption class="product_content">
                    <div class="price_box">
                        <span class="old_price"><?php echo !empty($product->sale_price) && $product->sale_price < $product->regular_price ? '৳'.number_format($product->regular_price / 100, 2) : ''?></span>  
                        <span class="current_price"><?php echo !empty($product->sale_price) && $product->sale_price < $product->regular_price ? '৳'.number_format($product->sale_price / 100, 2) : '৳'.number_format($product->regular_price / 100, 2) ;?></span>  
                    </div>
                    <h3 class="product_name"><a href="<?php echo route('frontend_single_product', $product->slug);?>"><?php echo $product->title;?></a></h3>
                </figcaption>
            </figure>
        </article>
        <?php
                
            } 
        ?>
        <?php
			$content = ob_get_contents();
			ob_end_clean();
			return $content;
    }


    public static function productModal(){
        ob_start();?>

        <!-- modal area start-->
       <div class="modal fade" id="modal_box" tabindex="-1" role="dialog"  aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div class="modal_body product_modal_body">
                            
                    </div>    
                </div>
            </div>
        </div>

        <!-- modal area end-->
        
        

        <script>
            $(document).ready(function(){
                $('.modalQuickView').click(function(e){
                    e.preventDefault();
                    let productId = $(this).attr('id');
                    console.log('Quick view clicked for product:', productId);
                    
                    // Show loading state
                    $('.product_modal_body').html('<div class="text-center p-4"><div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div></div>');
                    $('#modal_box').modal('show');
                    
                    $.ajax({
                        type : 'GET',
                        url :  '<?php echo url('product/quick-view');?>/'+productId,
                        success : function(data){
                            $('.product_modal_body').html(data);
                            console.log('Modal content loaded successfully');
                        },
                        error: function(xhr, status, error) {
                            console.log('Error:', error);
                            $('.product_modal_body').html('<div class="alert alert-danger">Error loading product details. Please try again.</div>');
                        }
                    })
                })
            })
        </script>
        

        <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

}








?>